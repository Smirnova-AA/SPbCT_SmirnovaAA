package com.example.kr_02_01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView textView1 = new TextView(this);
        TextView textView2 = new TextView(this);
        textView1.setTextSize(30);
        textView1.setPadding(16, 16, 16, 16);
        textView2.setTextSize(30);
        textView2.setPadding(16, 50, 16, 16);

        Bundle arguments = getIntent().getExtras();
        if(arguments!=null){
            double name = arguments.getDouble("name");
            double company = arguments.getDouble("company");
            double candy1 = name;
            double cookies1 = company;
            double price1 = name + company;
            double price2 = name * company;
            String priceA = Double.toString(price1);
            String priceB = Double.toString(price2);
            textView1.setText("a) Сумма: " + priceA + "\n");
            textView2.setText("б) Произведение: " + priceB);
        }
        setContentView(textView1);
        setContentView(textView2);
    }
    }