package com.company;

public class CommonResource {
    int x=0;
}
