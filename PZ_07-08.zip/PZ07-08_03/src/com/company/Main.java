package com.company;

public class Main {
    public static void main(String[] args) {
        Car c1 = new Car("Mersedes-Benz","S-klasse","S500", 7000000, 2015);
        c1.println();
        Car c2 = new Car("BMW","7 Series","S750 Li", 7050000, 2016);
        c2.println();
        Car c3 = new Car("Audi","A8","Long", 7450000, 2016);
        c3.println();
    }
}
