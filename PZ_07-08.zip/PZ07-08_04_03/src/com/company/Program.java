package com.company;

public class Program {
    public static void main(String[] args) {

        Type[] types = Type.values();
        for (Type s : types) { System.out.println(s); }
    }

}
