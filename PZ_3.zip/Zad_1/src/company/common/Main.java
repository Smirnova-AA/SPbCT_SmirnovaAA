package company.common;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        int a = console.nextInt();
        if (a<100)
            System.out.println("less");
        else
            System.out.println("not less");
    }
}
