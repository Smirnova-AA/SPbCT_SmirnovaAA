package company.common;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        String ned = console.nextLine();
        int n = console.nextInt();
        switch (n) {
            case 1:
                System.out.println("Понедельник: " + n);
                break;
            case 2:
                System.out.println("Вторник: "+n );
                break;
            case 3:
                System.out.println("Хорошо");
                break;
            case 4:
                System.out.println("Отлично");
                break;
            default:
                System.out.println("Ошибка! Такой оценки нет.");
                break;
        }
    }
}