package com.company;
import java.util.stream.IntStream;

public class Chis {

    private static boolean isDiffNum(int n) {
        int [] dig = new int[10];
        while (n > 0) {
            if ((dig[n % 10]++) == 1) return false;
            n /= 10;
        }
        return true;
    }

    public static void main(String[] args) {
        IntStream.rangeClosed(1000, 9999)
                .filter(Chis::isDiffNum)
                .forEach(System.out::println);
    }
}

