package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        System.out.println("*     *     *");
        System.out.println(" *   * *   * ");
        System.out.println("  * *   * *  ");
        System.out.println("   *     *   ");
    }
}
