package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int c1=2;
        int c2=4;
        double g = Math.sqrt(((c1*c1)+(c2*c2)));
        System.out.println("Гипотенуза = " + g);
        System.out.println("Периметр = " + (c1+c2+g));
        System.out.println("Площадь треугольника = " + (c1*c2)/2);
    }
}
