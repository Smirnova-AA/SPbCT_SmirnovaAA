package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner scan = new Scanner(System.in);
        System.out.println("Введите радиус: ");
        int r = scan.nextInt();
        int y = 0;
        int n = 0;
        int x = 1;
        double r2 = Math.sqrt(r);
        while (x <= r) {
            y = 1;
            while (y <= r){
                if (Math.sqrt(x) + Math.sqrt(y) <= r2)
                    n = n + 1;
                    y = y + 1;
            }
            x = x + 1;
        }
        n = 4 * n;
        n = n + 1;
        n = n + 4 * r;
        System.out.println("Количество точек = " + n);

    }
}
