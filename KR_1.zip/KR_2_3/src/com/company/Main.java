package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	// write your code here
        double k=0, m=0, s=0;

        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите три числа\nПервое число:");
        double a = scanner.nextDouble();
        System.out.println("Второе число:");
        double b = scanner.nextDouble();
        System.out.println("Третье число:");
        double c = scanner.nextDouble();
        k= a*2;
        m= b-3;
        s=c*c;
        System.out.println("Увеличение 1 числа в 2 раза = "+ k  + "\n" + "Уменьшение 2 числа на 3 = "+ m + "\n" + "Квадрат 3 числа = " + s);
        System.out.println("Сумма новых чисел = " + (k+m+s));
    }
}
