package com.company;
import java.util.*;
import java.lang.*;
public class Main {

    public static void main(String[] args) {
        Scanner Scan = new Scanner(System.in);
        System.out.print("a = ");
        int a = Scan.nextInt();
        System.out.print("b = ");
        int b = Scan.nextInt();
        System.out.print("c = ");
        int c = Scan.nextInt();
        int k = 0;

        if (a > 0) k++;
        if (b > 0) k++;
        if (c > 0) k++;

        System.out.println("Количество положительных чисел: "+k);
    }
}
