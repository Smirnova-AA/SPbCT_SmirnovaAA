package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите положительное целое число меньше 10:");
        int x = scanner.nextInt();
        String s;
        switch (x) {
            case 0:
                s = "aaa";
                break;
            case 1:
                s = "aab";
                break;
            case 2:
                s = "abb";
                break;
            case 3:
                s = "bbb";
                break;
            case 4:
                s = "bbc";
                break;
            case 5:
                s = "bcc";
                break;
            case 6:
                s = "ccc";
                break;
            case 7:
                s = "ccd";
                break;
            case 8:
                s = "cdd";
                break;
            case 9:
                s = "ddd";
                break;
            default:
                s = "Вы ввели неверное число";
        }
        System.out.println("Зашифрованная цифра " + x + ":\n" + s);

    }
}
