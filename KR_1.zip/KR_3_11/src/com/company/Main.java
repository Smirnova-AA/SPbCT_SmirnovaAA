package com.company;
import java.util.*;
import java.lang.*;
public class Main {

    public static void main(String[] args) {
        Scanner Scan = new Scanner(System.in);
        System.out.print("a = ");
        int a = Scan.nextInt();
        System.out.print("b = ");
        int b = Scan.nextInt();

        if (a != 10 && b != 10 && a % 2 == 0)
        System.out.println("Сумма= "+ (a+b));
        else
        System.out.println("Произведение = "+ a*b);
    }
}
