package company.common;

public class Main {

    public static void main(String[] args) {
	// write your code here
        System.out.println("char to int");
        char ch = '9';
        int i1 = Character.getNumericValue(ch);
        System.out.println(i1);

        int i2 = Character.digit(ch,10);
        System.out.println(i2);

    }
}
