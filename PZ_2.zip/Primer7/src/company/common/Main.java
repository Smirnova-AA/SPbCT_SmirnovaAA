package company.common;

public class Main {

    public static void main(String[] args) {
        System.out.println("int to long");
        int i = 2015;
        long l = (long) (i);
        System.out.println(l);

        System.out.println("int to float");
        int m = 2015;
        float f = (float) (m);
        System.out.println(f);

        System.out.println("long to int");
        long k = 214748364;
        int t = (int) k;
        System.out.println(t);

        System.out.println("double to int");
        double d = 3.14;
        int s = (int) d;
        System.out.println(s);

    }
}
