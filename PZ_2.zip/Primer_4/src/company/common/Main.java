package company.common;

public class Main {

    public static void main(String[] args) {
	// write your code here
        System.out.println("Преобразование числа в строку");
        System.out.println("int to string");
        int i = 35;
        String str = Integer.toString(i);
        System.out.println(str);

        System.out.println("double to string");
        double  m = 32.4e10;
        String st = Double.toString(m);
        System.out.println(st);

        System.out.println("long to string");
        long  n = 3422222;
        String sr = Long.toString(n);
        System.out.println(sr);

        System.out.println("float to string");
        float  o = 3.46f;
        String t = Float.toString(o);
        System.out.println(t);

    }
}
