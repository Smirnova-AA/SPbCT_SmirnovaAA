package company.common;

public class Main {

    public static void main(String[] args) {

        String s1 = "I have ";
        String s2 = " apples ";
        int num = 3;
        String s = s1 + num + s2;

        System.out.println(s);
    }

}
