package company.common;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        int x= 300000;
        System.out.println(x*x);

    }
}
