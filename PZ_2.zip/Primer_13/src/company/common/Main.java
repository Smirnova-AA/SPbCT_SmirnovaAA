package company.common;

public class Main {

    public static void main(String[] args) {
        // пример вызовет ошибку компиляции
        // пример вызовет ошибку компиляции
        byte b=5;
        byte c=-b;
    }
}
