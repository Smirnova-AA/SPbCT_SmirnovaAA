package company.common;

public class Main {

    public static void main(String[] args) {
	// write your code here
        System.out.println("char to string");
        char ch = 'S';
        String charToString = Character.toString(ch);
        System.out.println(charToString);

        String str = "" + ch;
        System.out.println(str);

        String fromChar = new String(new char[] { ch });
        System.out.println(fromChar);

        String valueOfchar = String.valueOf(ch);
        System.out.println(valueOfchar);


    }
}
