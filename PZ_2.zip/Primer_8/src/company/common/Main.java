
package company.common;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        Point p1 = new Point(3,5);
        Point p2=p1;
        p1.x=7;
        System.out.println(p2.x);
    }
}
