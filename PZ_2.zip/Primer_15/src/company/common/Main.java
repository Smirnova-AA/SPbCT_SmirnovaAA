package company.common;

public class Main {

    public static void main(String[] args) {
        System.out.println("Рассмотрение операторов");
        byte x=-128;
        System.out.println(-x);

        byte y=127;
        System.out.println(++y);

        System.out.println("Оператор конкатенации со строкой");
        int с=1;
        System.out.println("с="+с);

        System.out.println("Работа с типом char");
        char c1=10;
        char c2='A';
        // латинская буква A (\u0041, код 65)
        int i=c1+c2-'B';
        System.out.println("i="+i);
    }
}
