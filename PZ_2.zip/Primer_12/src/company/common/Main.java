package company.common;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        System.out.println("сколько секунд содержится в неделе и в месяце:");
        System.out.println(1000*60*60*24*7);
        // вычисление для недели
        System.out.println(1000*60*60*24*30L);
        // вычисление для месяца
    }
}
