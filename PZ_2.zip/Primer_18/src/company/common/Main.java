package company.common;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        System.out.println("Метод getClass");
        String s = "abc";
        Class cl=s.getClass();
        System.out.println(cl.getName());

        System.out.println("Метод equals");
        Point p1=new Point(2,3);
        Point p2=new Point(2,3);
        System.out.println(p1.equals(p2));

        System.out.println("От какого класса был порожден объект и, благодаря хеш-коду, различать разные объекты, созданные от одного класса");
        System.out.println(new Object());

        System.out.println("Класс String");
        String s1 = "abc";
        String s2 = "abc";
        String s3 = "a"+"bc";
        System.out.println(s1==s2);
        System.out.println(s1==s3);
    }
}
